import os
import datetime
import json

# ============================================================
#           HOTEL TOGETHER - ERP SYSTEM
# ============================================================

# Database (In-Memory Storage)
inventory_db = {
    "Branch 1 - Downtown": {
        "Rice": {"quantity": 50, "unit": "kg", "min_stock": 20},
        "Chicken": {"quantity": 30, "unit": "kg", "min_stock": 10},
        "Bread": {"quantity": 100, "unit": "pieces", "min_stock": 30},
        "Milk": {"quantity": 40, "unit": "liters", "min_stock": 15},
        "Eggs": {"quantity": 200, "unit": "pieces", "min_stock": 50},
        "Cooking Oil": {"quantity": 20, "unit": "liters", "min_stock": 8},
        "Salt": {"quantity": 15, "unit": "kg", "min_stock": 5},
        "Sugar": {"quantity": 25, "unit": "kg", "min_stock": 10},
        "Soap": {"quantity": 60, "unit": "pieces", "min_stock": 20},
        "Towels": {"quantity": 80, "unit": "pieces", "min_stock": 30},
    },
    "Branch 2 - Airport": {
        "Rice": {"quantity": 80, "unit": "kg", "min_stock": 25},
        "Chicken": {"quantity": 15, "unit": "kg", "min_stock": 10},
        "Bread": {"quantity": 60, "unit": "pieces", "min_stock": 30},
        "Milk": {"quantity": 10, "unit": "liters", "min_stock": 15},
        "Eggs": {"quantity": 150, "unit": "pieces", "min_stock": 50},
        "Cooking Oil": {"quantity": 5, "unit": "liters", "min_stock": 8},
        "Salt": {"quantity": 8, "unit": "kg", "min_stock": 5},
        "Sugar": {"quantity": 12, "unit": "kg", "min_stock": 10},
        "Soap": {"quantity": 40, "unit": "pieces", "min_stock": 20},
        "Towels": {"quantity": 25, "unit": "pieces", "min_stock": 30},
    },
    "Branch 3 - Beach Side": {
        "Rice": {"quantity": 60, "unit": "kg", "min_stock": 20},
        "Chicken": {"quantity": 40, "unit": "kg", "min_stock": 10},
        "Bread": {"quantity": 80, "unit": "pieces", "min_stock": 30},
        "Milk": {"quantity": 30, "unit": "liters", "min_stock": 15},
        "Eggs": {"quantity": 100, "unit": "pieces", "min_stock": 50},
        "Cooking Oil": {"quantity": 18, "unit": "liters", "min_stock": 8},
        "Salt": {"quantity": 20, "unit": "kg", "min_stock": 5},
        "Sugar": {"quantity": 30, "unit": "kg", "min_stock": 10},
        "Soap": {"quantity": 70, "unit": "pieces", "min_stock": 20},
        "Towels": {"quantity": 50, "unit": "pieces", "min_stock": 30},
    }
}

# Users (Manager Login)
users = {
    "admin": {"password": "admin123", "role": "Admin", "branch": "All"},
    "manager1": {"password": "mgr1pass", "role": "Manager", "branch": "Branch 1 - Downtown"},
    "manager2": {"password": "mgr2pass", "role": "Manager", "branch": "Branch 2 - Airport"},
    "manager3": {"password": "mgr3pass", "role": "Manager", "branch": "Branch 3 - Beach Side"},
}

# Activity Log
activity_log = []

# Current logged-in user
current_user = None


# ============================================================
#                   HELPER FUNCTIONS
# ============================================================

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def print_header():
    print("=" * 65)
    print("        🏨  HOTEL TOGETHER - ERP INVENTORY SYSTEM  🏨")
    print("=" * 65)
    if current_user:
        print(f"  👤 User: {current_user['name']}  |  Role: {current_user['role']}  |  Branch: {current_user['branch']}")
        print(f"  📅 Date: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 65)

def print_divider():
    print("-" * 65)

def log_activity(action):
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    activity_log.append({
        "time": timestamp,
        "user": current_user['name'],
        "action": action
    })

def status_label(item_data):
    """Return status based on quantity vs minimum stock"""
    qty = item_data["quantity"]
    min_stock = item_data["min_stock"]
    if qty == 0:
        return "❌ OUT OF STOCK"
    elif qty <= min_stock:
        return "⚠️  LOW STOCK"
    else:
        return "✅ AVAILABLE"


# ============================================================
#                   LOGIN SYSTEM
# ============================================================

def login():
    global current_user
    clear_screen()
    print("=" * 65)
    print("        🏨  HOTEL TOGETHER - ERP SYSTEM LOGIN  🏨")
    print("=" * 65)
    print("\n  Welcome to Hotel Together Inventory Management System")
    print_divider()

    attempts = 3
    while attempts > 0:
        print(f"\n  Login Attempts Remaining: {attempts}")
        username = input("\n  👤 Enter Username: ").strip()
        password = input("  🔑 Enter Password: ").strip()

        if username in users and users[username]["password"] == password:
            current_user = {
                "name": username,
                "role": users[username]["role"],
                "branch": users[username]["branch"]
            }
            print(f"\n  ✅ Login Successful! Welcome, {username}!")
            print(f"  🏢 Your Branch: {users[username]['branch']}")
            input("\n  Press Enter to Continue...")
            return True
        else:
            attempts -= 1
            print("  ❌ Invalid Username or Password! Try Again.")

    print("\n  🔒 Too many failed attempts. Access Denied!")
    return False


# ============================================================
#               VIEW INVENTORY FUNCTIONS
# ============================================================

def view_inventory_single_branch(branch_name):
    """View inventory for a single branch"""
    clear_screen()
    print_header()
    print(f"\n  📦 INVENTORY - {branch_name}")
    print_divider()

    items = inventory_db[branch_name]
    if not items:
        print("  No items found in inventory.")
        return

    print(f"\n  {'No.':<5} {'Item Name':<20} {'Quantity':<12} {'Unit':<12} {'Min Stock':<12} {'Status'}")
    print_divider()

    for i, (item, data) in enumerate(items.items(), 1):
        status = status_label(data)
        print(f"  {i:<5} {item:<20} {data['quantity']:<12} {data['unit']:<12} {data['min_stock']:<12} {status}")

    print_divider()
    # Summary
    total_items = len(items)
    available = sum(1 for d in items.values() if d["quantity"] > d["min_stock"])
    low_stock = sum(1 for d in items.values() if 0 < d["quantity"] <= d["min_stock"])
    out_of_stock = sum(1 for d in items.values() if d["quantity"] == 0)

    print(f"\n  📊 SUMMARY:")
    print(f"     Total Items   : {total_items}")
    print(f"     ✅ Available   : {available}")
    print(f"     ⚠️  Low Stock   : {low_stock}")
    print(f"     ❌ Out of Stock: {out_of_stock}")
    print_divider()
    input("\n  Press Enter to go back...")

def view_all_branches_inventory():
    """View inventory for all branches"""
    clear_screen()
    print_header()
    print("\n  📦 ALL BRANCHES - INVENTORY OVERVIEW")
    print_divider()

    for branch_name, items in inventory_db.items():
        print(f"\n  🏢 {branch_name}")
        print(f"  {'Item Name':<20} {'Quantity':<12} {'Unit':<12} {'Status'}")
        print("  " + "-" * 55)

        for item, data in items.items():
            status = status_label(data)
            print(f"  {item:<20} {data['quantity']:<12} {data['unit']:<12} {status}")

        print()

    input("  Press Enter to go back...")

def view_low_stock_items():
    """Show items with low stock or out of stock across all branches"""
    clear_screen()
    print_header()
    print("\n  ⚠️  LOW STOCK & OUT OF STOCK ALERTS")
    print_divider()

    found = False
    for branch_name, items in inventory_db.items():
        branch_alerts = []
        for item, data in items.items():
            if data["quantity"] <= data["min_stock"]:
                branch_alerts.append((item, data))

        if branch_alerts:
            found = True
            print(f"\n  🏢 {branch_name}")
            print(f"  {'Item':<20} {'Quantity':<12} {'Min Stock':<12} {'Status'}")
            print("  " + "-" * 55)
            for item, data in branch_alerts:
                status = status_label(data)
                print(f"  {item:<20} {data['quantity']:<12} {data['min_stock']:<12} {status}")

    if not found:
        print("\n  ✅ All items are sufficiently stocked across all branches!")

    print_divider()
    input("\n  Press Enter to go back...")

def search_item():
    """Search for a specific item across branches"""
    clear_screen()
    print_header()
    print("\n  🔍 SEARCH ITEM")
    print_divider()

    search_term = input("\n  Enter item name to search: ").strip().lower()
    found = False

    print(f"\n  Search Results for: '{search_term}'")
    print_divider()
    print(f"  {'Branch':<30} {'Item':<20} {'Quantity':<12} {'Unit':<10} {'Status'}")
    print("  " + "-" * 60)

    for branch_name, items in inventory_db.items():
        for item, data in items.items():
            if search_term in item.lower():
                status = status_label(data)
                print(f"  {branch_name:<30} {item:<20} {data['quantity']:<12} {data['unit']:<10} {status}")
                found = True

    if not found:
        print(f"  ❌ No item found matching '{search_term}'")

    print_divider()
    input("\n  Press Enter to go back...")


# ============================================================
#               MANAGE INVENTORY FUNCTIONS
# ============================================================

def add_new_item(branch_name):
    """Add a new item to inventory"""
    clear_screen()
    print_header()
    print(f"\n  ➕ ADD NEW ITEM - {branch_name}")
    print_divider()

    item_name = input("\n  Enter Item Name: ").strip().title()
    if item_name in inventory_db[branch_name]:
        print(f"  ⚠️  '{item_name}' already exists! Use 'Update Quantity' instead.")
        input("  Press Enter to go back...")
        return

    try:
        quantity = int(input("  Enter Quantity: "))
        unit = input("  Enter Unit (kg/liters/pieces): ").strip()
        min_stock = int(input("  Enter Minimum Stock Level: "))

        inventory_db[branch_name][item_name] = {
            "quantity": quantity,
            "unit": unit,
            "min_stock": min_stock
        }
        log_activity(f"Added new item '{item_name}' (Qty: {quantity} {unit}) in {branch_name}")
        print(f"\n  ✅ '{item_name}' added successfully to {branch_name}!")
    except ValueError:
        print("  ❌ Invalid input. Quantity and Min Stock must be numbers.")

    input("\n  Press Enter to go back...")

def update_quantity(branch_name):
    """Update quantity of an existing item"""
    clear_screen()
    print_header()
    print(f"\n  🔄 UPDATE QUANTITY - {branch_name}")
    print_divider()

    items = inventory_db[branch_name]
    item_list = list(items.keys())

    print("\n  Available Items:")
    for i, item in enumerate(item_list, 1):
        print(f"  {i}. {item} (Current: {items[item]['quantity']} {items[item]['unit']})")

    print_divider()
    try:
        choice = int(input("\n  Select Item Number: ")) - 1
        if 0 <= choice < len(item_list):
            item_name = item_list[choice]
            current_qty = items[item_name]["quantity"]

            print(f"\n  Item: {item_name}")
            print(f"  Current Quantity: {current_qty} {items[item_name]['unit']}")
            print("\n  1. Add Stock")
            print("  2. Remove Stock")
            print("  3. Set Exact Quantity")

            action = input("\n  Choose Action (1/2/3): ").strip()
            new_qty = int(input("  Enter Quantity: "))

            if action == "1":
                items[item_name]["quantity"] += new_qty
                log_activity(f"Added {new_qty} to '{item_name}' in {branch_name}. New Qty: {items[item_name]['quantity']}")
                print(f"\n  ✅ Stock Added! New Quantity: {items[item_name]['quantity']} {items[item_name]['unit']}")
            elif action == "2":
                if new_qty > current_qty:
                    print("  ❌ Cannot remove more than current stock!")
                else:
                    items[item_name]["quantity"] -= new_qty
                    log_activity(f"Removed {new_qty} from '{item_name}' in {branch_name}. New Qty: {items[item_name]['quantity']}")
                    print(f"\n  ✅ Stock Removed! New Quantity: {items[item_name]['quantity']} {items[item_name]['unit']}")
            elif action == "3":
                items[item_name]["quantity"] = new_qty
                log_activity(f"Set '{item_name}' quantity to {new_qty} in {branch_name}")
                print(f"\n  ✅ Quantity Updated! New Quantity: {new_qty} {items[item_name]['unit']}")
            else:
                print("  ❌ Invalid Action!")
        else:
            print("  ❌ Invalid Item Selection!")
    except ValueError:
        print("  ❌ Please enter valid numbers!")

    input("\n  Press Enter to go back...")

def delete_item(branch_name):
    """Delete an item from inventory"""
    clear_screen()
    print_header()
    print(f"\n  🗑️  DELETE ITEM - {branch_name}")
    print_divider()

    items = inventory_db[branch_name]
    item_list = list(items.keys())

    print("\n  Available Items:")
    for i, item in enumerate(item_list, 1):
        print(f"  {i}. {item}")

    print_divider()
    try:
        choice = int(input("\n  Select Item Number to Delete: ")) - 1
        if 0 <= choice < len(item_list):
            item_name = item_list[choice]
            confirm = input(f"\n  ⚠️  Are you sure you want to delete '{item_name}'? (yes/no): ").strip().lower()
            if confirm == "yes":
                del inventory_db[branch_name][item_name]
                log_activity(f"Deleted item '{item_name}' from {branch_name}")
                print(f"\n  ✅ '{item_name}' deleted successfully!")
            else:
                print("  ❌ Deletion cancelled.")
        else:
            print("  ❌ Invalid selection!")
    except ValueError:
        print("  ❌ Invalid input!")

    input("\n  Press Enter to go back...")

def transfer_stock():
    """Transfer stock between branches (Admin only)"""
    clear_screen()
    print_header()
    print("\n  🔁 TRANSFER STOCK BETWEEN BRANCHES")
    print_divider()

    branches = list(inventory_db.keys())
    print("\n  Select Source Branch:")
    for i, b in enumerate(branches, 1):
        print(f"  {i}. {b}")

    try:
        src_idx = int(input("\n  Source Branch: ")) - 1
        dst_idx = int(input("  Destination Branch: ")) - 1

        if src_idx == dst_idx:
            print("  ❌ Source and Destination cannot be the same!")
            input("  Press Enter to go back...")
            return

        src_branch = branches[src_idx]
        dst_branch = branches[dst_idx]

        print(f"\n  Items in {src_branch}:")
        items = inventory_db[src_branch]
        item_list = list(items.keys())
        for i, item in enumerate(item_list, 1):
            print(f"  {i}. {item} (Available: {items[item]['quantity']} {items[item]['unit']})")

        item_idx = int(input("\n  Select Item to Transfer: ")) - 1
        item_name = item_list[item_idx]
        transfer_qty = int(input(f"  Enter Quantity to Transfer: "))

        if transfer_qty > inventory_db[src_branch][item_name]["quantity"]:
            print("  ❌ Insufficient stock for transfer!")
        else:
            inventory_db[src_branch][item_name]["quantity"] -= transfer_qty
            if item_name in inventory_db[dst_branch]:
                inventory_db[dst_branch][item_name]["quantity"] += transfer_qty
            else:
                inventory_db[dst_branch][item_name] = {
                    "quantity": transfer_qty,
                    "unit": inventory_db[src_branch][item_name]["unit"],
                    "min_stock": inventory_db[src_branch][item_name]["min_stock"]
                }
            log_activity(f"Transferred {transfer_qty} of '{item_name}' from {src_branch} to {dst_branch}")
            print(f"\n  ✅ Successfully transferred {transfer_qty} {item_name} from {src_branch} to {dst_branch}!")
    except (ValueError, IndexError):
        print("  ❌ Invalid input!")

    input("\n  Press Enter to go back...")


# ============================================================
#               REPORTS FUNCTIONS
# ============================================================

def generate_report():
    """Generate full inventory report"""
    clear_screen()
    print_header()
    print("\n  📊 FULL INVENTORY REPORT")
    print(f"  Generated: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print_divider()

    total_all = 0
    for branch_name, items in inventory_db.items():
        available = sum(1 for d in items.values() if d["quantity"] > d["min_stock"])
        low = sum(1 for d in items.values() if 0 < d["quantity"] <= d["min_stock"])
        out = sum(1 for d in items.values() if d["quantity"] == 0)

        print(f"\n  🏢 {branch_name}")
        print(f"     Total Items    : {len(items)}")
        print(f"     ✅ Available    : {available}")
        print(f"     ⚠️  Low Stock    : {low}")
        print(f"     ❌ Out of Stock : {out}")
        total_all += len(items)

    print_divider()
    print(f"\n  🌐 OVERALL TOTAL ITEMS TRACKED: {total_all}")
    print_divider()
    log_activity("Generated full inventory report")
    input("\n  Press Enter to go back...")

def view_activity_log():
    """View activity log"""
    clear_screen()
    print_header()
    print("\n  📋 ACTIVITY LOG")
    print_divider()

    if not activity_log:
        print("\n  No activities recorded yet.")
    else:
        for log in activity_log[-20:]:  # Show last 20 activities
            print(f"  [{log['time']}] {log['user']}: {log['action']}")

    print_divider()
    input("\n  Press Enter to go back...")


# ============================================================
#               MENU SYSTEMS
# ============================================================

def branch_menu(branch_name):
    """Menu for a specific branch"""
    while True:
        clear_screen()
        print_header()
        print(f"\n  🏢 BRANCH MENU - {branch_name}")
        print_divider()
        print("  1. 📦 View Inventory")
        print("  2. ➕ Add New Item")
        print("  3. 🔄 Update Item Quantity")
        print("  4. 🗑️  Delete Item")
        print("  5. 🔙 Back to Main Menu")
        print_divider()

        choice = input("\n  Enter Your Choice (1-5): ").strip()

        if choice == "1":
            view_inventory_single_branch(branch_name)
        elif choice == "2":
            add_new_item(branch_name)
        elif choice == "3":
            update_quantity(branch_name)
        elif choice == "4":
            delete_item(branch_name)
        elif choice == "5":
            break
        else:
            print("  ❌ Invalid choice!")
            input("  Press Enter to continue...")

def manager_menu():
    """Menu for Branch Managers"""
    branch_name = current_user["branch"]
    while True:
        clear_screen()
        print_header()
        print(f"\n  🏢 MANAGER MENU - {branch_name}")
        print_divider()
        print("  1. 📦 View My Branch Inventory")
        print("  2. ➕ Add New Item")
        print("  3. 🔄 Update Item Quantity")
        print("  4. 🗑️  Delete Item")
        print("  5. ⚠️  View Low Stock Alerts")
        print("  6. 🔍 Search Item")
        print("  7. 🚪 Logout")
        print_divider()

        choice = input("\n  Enter Your Choice (1-7): ").strip()

        if choice == "1":
            view_inventory_single_branch(branch_name)
        elif choice == "2":
            add_new_item(branch_name)
        elif choice == "3":
            update_quantity(branch_name)
        elif choice == "4":
            delete_item(branch_name)
        elif choice == "5":
            view_low_stock_items()
        elif choice == "6":
            search_item()
        elif choice == "7":
            print("\n  👋 Logging out... Goodbye!")
            break
        else:
            print("  ❌ Invalid choice!")
            input("  Press Enter to continue...")

def admin_menu():
    """Menu for Admin"""
    while True:
        clear_screen()
        print_header()
        print("\n  👑 ADMIN MENU")
        print_divider()
        print("  1. 🌐 View All Branches Inventory")
        print("  2. 🏢 Manage Branch 1 - Downtown")
        print("  3. 🏢 Manage Branch 2 - Airport")
        print("  4. 🏢 Manage Branch 3 - Beach Side")
        print("  5. ⚠️  View Low Stock Alerts (All Branches)")
        print("  6. 🔁 Transfer Stock Between Branches")
        print("  7. 🔍 Search Item Across All Branches")
        print("  8. 📊 Generate Full Report")
        print("  9. 📋 View Activity Log")
        print("  0. 🚪 Logout")
        print_divider()

        choice = input("\n  Enter Your Choice (0-9): ").strip()

        if choice == "1":
            view_all_branches_inventory()
        elif choice == "2":
            branch_menu("Branch 1 - Downtown")
        elif choice == "3":
            branch_menu("Branch 2 - Airport")
        elif choice == "4":
            branch_menu("Branch 3 - Beach Side")
        elif choice == "5":
            view_low_stock_items()
        elif choice == "6":
            transfer_stock()
        elif choice == "7":
            search_item()
        elif choice == "8":
            generate_report()
        elif choice == "9":
            view_activity_log()
        elif choice == "0":
            print("\n  👋 Logging out... Goodbye!")
            break
        else:
            print("  ❌ Invalid choice!")
            input("  Press Enter to continue...")


# ============================================================
#               MAIN PROGRAM
# ============================================================

def main():
    global current_user

    while True:
        if login():
            if current_user["role"] == "Admin":
                admin_menu()
            elif current_user["role"] == "Manager":
                manager_menu()
            current_user = None  # Reset after logout

        # Ask to login again or exit
        again = input("\n  🔄 Login Again? (yes/no): ").strip().lower()
        if again != "yes":
            clear_screen()
            print("=" * 65)
            print("    🏨  Thank you for using Hotel Together ERP System!")
            print("=" * 65)
            break

if __name__ == "__main__":
    main()
